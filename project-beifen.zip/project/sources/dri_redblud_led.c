#include <string.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include "dri_rb_led.h"
#include <stdio.h>

#include "oled_app.h"

#define Address         0x3c //OLED设备地址 
int led_cnt = 0;
extern unsigned char temperatureS[20];
extern unsigned char humidityS[20];
extern unsigned char L_C[20];
extern unsigned char S_R[20];
extern int next_red_t, next_green_t;
unsigned char LED_CNTS[20]; 

unsigned char LED_STATE[20];
unsigned char LED_STATE_NEXT[20];

void choose_color_time(char *color, int time ,int *led_cnt)
{
    if (strcmp(color, RED_GPIO_INDEX) == 0)
    {
        int cnt_led = time;
        red_on();
        yellow_off();
        green_off();                   
        for (int cnt_led = time; cnt_led > 0; cnt_led--) {
            // 使用 dtostrf 函数将浮点数转换为字符串
            strcpy(LED_STATE, "RED");
            sprintf(LED_CNTS, "now: %s:%d", LED_STATE, cnt_led);
            sprintf(LED_STATE_NEXT, "next: red:%d,grn:%d", next_red_t, next_green_t);
            OLED_ShowStr(Address, 0, 1, temperatureS, 1);  //测试6*8字符
            OLED_ShowStr(Address, 0, 2, humidityS, 1);     //测试8*16字符
            OLED_ShowStr(Address, 0, 3, L_C, 1);           //测试8*16字符
            OLED_ShowStr(Address, 0, 4, S_R, 1);           //测试8*16字符
            OLED_ShowStr(Address, 0, 5, LED_CNTS, 1);      //测试8*16字符
            OLED_ShowStr(Address, 0, 6, LED_STATE_NEXT, 1);//测试8*16字符 
            usleep(1000 * 500);
            OLED_CLS(Address); //清屏
        }
        red_off();
    }
    else if (strcmp(color, YELLOW_GPIO_INDEX) == 0)
    {
        int cnt_led = time;
        red_off();
        yellow_on();
        green_off();       
        for (int cnt_led = time; cnt_led > 0; cnt_led--) {
            // 使用 dtostrf 函数将浮点数转换为字符串
            strcpy(LED_STATE, "YELLOW");
            sprintf(LED_CNTS, "now: %s:%d", LED_STATE, cnt_led);
            sprintf(LED_STATE_NEXT, "next: red:%d,grn:%d", next_red_t, next_green_t);
            OLED_ShowStr(Address, 0, 1, temperatureS, 1);  //测试6*8字符
            OLED_ShowStr(Address, 0, 2, humidityS, 1);     //测试8*16字符
            OLED_ShowStr(Address, 0, 3, L_C, 1);           //测试8*16字符
            OLED_ShowStr(Address, 0, 4, S_R, 1);           //测试8*16字符
            OLED_ShowStr(Address, 0, 5, LED_CNTS, 1);      //测试8*16字符    
            OLED_ShowStr(Address, 0, 6, LED_STATE_NEXT, 1);      //测试8*16字符 
            usleep(1000 * 500);
            OLED_CLS(Address); //清屏
        }
        yellow_off();
    }
    else if (strcmp(color, GREEN_GPIO_INDEX) == 0)
    {
        int cnt_led = time;
        red_off();
        yellow_off();
        green_on();
        for (int cnt_led = time; cnt_led > 0; cnt_led--) {
            // 使用 dtostrf 函数将浮点数转换为字符串
            strcpy(LED_STATE, "GREEN");
            sprintf(LED_CNTS, "%s:%d", LED_STATE, cnt_led);
            sprintf(LED_STATE_NEXT, "next: red:%d,grn:%d", next_red_t, next_green_t);
            OLED_ShowStr(Address, 0, 1, temperatureS, 1);  //测试6*8字符
            OLED_ShowStr(Address, 0, 2, humidityS, 1);     //测试8*16字符
            OLED_ShowStr(Address, 0, 3, L_C, 1);           //测试8*16字符
            OLED_ShowStr(Address, 0, 4, S_R, 1);           //测试8*16字符
            OLED_ShowStr(Address, 0, 5, LED_CNTS, 1);      //测试8*16字符
            OLED_ShowStr(Address, 0, 6, LED_STATE_NEXT, 1);      //测试8*16字符 
            usleep(1000 * 500);
            OLED_CLS(Address); //清屏
        }
        green_off();
    }
    else
    {
        printf("choose_color_time匹配错误");
    }
}

void traffic_led_mod(int red_time, int green_time)
{
     choose_color_time(RED_GPIO_INDEX, red_time, &led_cnt);
     choose_color_time(YELLOW_GPIO_INDEX, 3 ,&led_cnt);
     choose_color_time(GREEN_GPIO_INDEX, green_time, &led_cnt);
}

int red_init(void)
{
   int fd;
   //index config
   fd = open("/sys/class/gpio/export", O_WRONLY);
   if(fd < 0)
      return 1 ;

   write(fd, RED_GPIO_INDEX, strlen(RED_GPIO_INDEX));
   close(fd);

   //direction config
   fd = open("/sys/class/gpio/gpio" RED_GPIO_INDEX "/direction", O_WRONLY);
   if(fd < 0)
      return 2;

   write(fd, "out", strlen("out"));
   close(fd);

   return 0;
}

int yellow_init(void)
{
   int fd;
   //index config
   fd = open("/sys/class/gpio/export", O_WRONLY);
   if(fd < 0)
      return 1 ;

   write(fd, YELLOW_GPIO_INDEX, strlen(YELLOW_GPIO_INDEX));
   close(fd);

   //direction config
   fd = open("/sys/class/gpio/gpio" YELLOW_GPIO_INDEX "/direction", O_WRONLY);
   if(fd < 0)
      return 2;

   write(fd, "out", strlen("out"));
   close(fd);

   return 0;
}

int green_init(void)
{
   int fd;
   //index config
   fd = open("/sys/class/gpio/export", O_WRONLY);
   if(fd < 0)
      return 1 ;

   write(fd, GREEN_GPIO_INDEX, strlen(GREEN_GPIO_INDEX));
   close(fd);

   //direction config
   fd = open("/sys/class/gpio/gpio" GREEN_GPIO_INDEX "/direction", O_WRONLY);
   if(fd < 0)
      return 2;

   write(fd, "out", strlen("out"));
   close(fd);

   return 0;
}


int rbled_init(void)
{
   red_init();
   yellow_init();
   green_init();
   return 0;
}

int rbled_deinit(void)
{
   int fd;
   fd = open("/sys/class/gpio/unexport", O_WRONLY);
   if(fd < 0)
      return 1;

   write(fd, RED_GPIO_INDEX, strlen(RED_GPIO_INDEX));
   close(fd);
   
   fd = open("/sys/class/gpio/unexport", O_WRONLY);
   if(fd < 0)
      return 1;

   write(fd, YELLOW_GPIO_INDEX, strlen(YELLOW_GPIO_INDEX));
   close(fd);
      
   fd = open("/sys/class/gpio/unexport", O_WRONLY);
   if(fd < 0)
      return 1;

   write(fd, GREEN_GPIO_INDEX, strlen(GREEN_GPIO_INDEX));
   close(fd);

   return 0;
}


int red_on(void)
{
   int fd;

   fd = open("/sys/class/gpio/gpio" RED_GPIO_INDEX "/value", O_WRONLY);
   if(fd < 0)
      return 1;

   write(fd, "0", 1);
   close(fd);

   return 0;
}

int red_off(void)
{
   int fd;

   fd = open("/sys/class/gpio/gpio" RED_GPIO_INDEX "/value", O_WRONLY);
   if(fd < 0)
      return 1;

   write(fd, "1", 1);
   close(fd);

   return 0;
}


int yellow_on(void)
{
   int fd;

   fd = open("/sys/class/gpio/gpio" YELLOW_GPIO_INDEX "/value", O_WRONLY);
   if(fd < 0)
      return 1;

   write(fd, "0", 1);
   close(fd);

   return 0;
}

int yellow_off(void)
{
   int fd;

   fd = open("/sys/class/gpio/gpio" YELLOW_GPIO_INDEX "/value", O_WRONLY);
   if(fd < 0)
      return 1;

   write(fd, "1", 1);
   close(fd);

   return 0;
}

int green_on(void)
{
   int fd;

   fd = open("/sys/class/gpio/gpio" GREEN_GPIO_INDEX "/value", O_WRONLY);
   if(fd < 0)
      return 1;

   write(fd, "0", 1);
   close(fd);

   return 0;
}

int green_off(void)
{
   int fd;

   fd = open("/sys/class/gpio/gpio" GREEN_GPIO_INDEX "/value", O_WRONLY);
   if(fd < 0)
      return 1;

   write(fd, "1", 1);
   close(fd);

   return 0;
}