#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <linux/i2c.h>
#include <linux/i2c-dev.h>
#include <string.h>
#include "dht20.h"

void delay(int time)
{
    while (time--)
    {}
}

/* IIC д����
*   ����˵����fd���򿪵��豸�ļ������ rg, ����ֵ�� val��Ҫд�������
*   ����ֵ��  �ɹ�������0. ʧ�ܣ����� -1
*/
static int i2c_write_dht(int fd, unsigned char addr, const void* pBuf, size_t size)
{
    int retries;
    uint8_t* _pBuf = (uint8_t*)pBuf;

    //���õ�ַ���ȣ�0Ϊ7λ��ַ
    ioctl(fd, I2C_TENBIT, 0);

    //���ôӻ���ַ
    if (ioctl(fd, I2C_SLAVE, addr) < 0) {
        printf("fail to set i2c device slave address!\n");
        close(fd);
        return -1;
    }

    //�����ղ���ACKʱ�����Դ���
    ioctl(fd, I2C_RETRIES, 5);

    if (write(fd, _pBuf, size) == size) {
        return 0;
    }
    else {
        return -1;
    }
}

static int i2c_read(int fd, uint8_t addr, void* pBuf, size_t size)
{
   //���õ�ַ���ȣ�0Ϊ7λ��ַ
    ioctl(fd, I2C_TENBIT, 0);
    uint8_t* _pBuf = (uint8_t*)pBuf;

    //���ôӻ���ַ
    if (ioctl(fd, I2C_SLAVE, addr) < 0) {
        printf("fail to set i2c device slave address!\n");
        close(fd);
        return -1;
    }

    //�����ղ���ACKʱ�����Դ���
    ioctl(fd, I2C_RETRIES, 5);
    read(fd, _pBuf, size);

    return 0;
}


int DFRobot_DHT20_Init(int fd, unsigned char addr)
{

    uint8_t readCMD[3] = { 0x71 };
    uint8_t data;
    delay(100);
    i2c_write_dht(fd, addr, readCMD, 1);
    i2c_read(fd, addr, &data, 1);
    //Serial.println(data);
    if ((data | 0x8) == 0) {
        return 1;
    }
    else
        return 0;
    //if (data == 255) return 1;
    
}

float getTemperature(int fd, unsigned char addr)
{
    uint8_t readCMD[3] = { 0xac,0x33,0x00 };
    uint8_t data[6] = { 0 };
    int retries = 10;
    float temperature;
    // when the returned data is wrong, request to get data again until the data is correct. 
    i2c_write_dht(fd, addr, readCMD, 3);
    while (retries--) {
        delay(10);
        i2c_read(fd, addr, data, 6);
        if ((data[0] >> 7) == 0) 
        {
            break;
        }
    }
    uint32_t temp = data[3] & 0xff;
    uint32_t temp1 = data[4] & 0xff;
    uint32_t rawData = 0;
    rawData = ((temp & 0xf) << 16) + (temp1 << 8) + (data[5]);
    temperature = (float)rawData / 5242 - 50;
    return temperature;
}

float getHumidity(int fd, unsigned char addr)
{
    uint8_t readCMD[3] = { 0xac,0x33,0x00 };
    uint8_t data[6] = { 0 };
    int retries = 10;
    float humidity;
    // when the returned data is wrong, request to get data again until the data is correct. 
    i2c_write_dht(fd, addr, readCMD, 3);
    while (retries--) {
        delay(10);
        i2c_read(fd, addr, data, 6);
        if ((data[0] >> 7) == 0) {
            break;
        }
    }
    uint32_t temp = data[1] & 0xff;
    uint32_t temp1 = data[2] & 0xff;
    uint32_t rawData = 0;
    rawData = (temp << 12) + (temp1 << 4) + ((data[3] & 0xf0) >> 4);
    humidity = (float)rawData / 0x100000;
    return humidity;
}