#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <errno.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <termios.h>
#include <stdlib.h>

#include "lora.h"
#include "uart.h"

int MD0_init(void)
{
	int fd;
	//index config
	fd = open("/sys/class/gpio/export", O_WRONLY);
	if (fd < 0)
		return 1;
	write(fd, MD0, strlen(MD0));
	close(fd);
	//direction config
	fd = open("/sys/class/gpio/gpio" MD0 "/direction", O_WRONLY);
	if (fd < 0)
		return 2;
	write(fd, "out", strlen("out"));
	close(fd);
	return 0;
}

int lora_AT_req(int fd)
{
	int fd0, iRet;
	fd0 = open("/sys/class/gpio/gpio"MD0"/value", O_WRONLY);
	if (fd0 < 0)
		return 1;
	write(fd0, "1", 1);//��MDO���ڸߵ�ƽ��������ģʽ
	iRet = set_opt(fd, 115200, 8, 'N', 1);
	if (iRet)
	{
		printf("set port err!\n");
		return -1;
	}
	close(fd0);
	return 0;
}

int lora_NAT_req(int fd)
{
	int fd0,iRet;
	fd0 = open("/sys/class/gpio/gpio"MD0"/value", O_WRONLY);
	if (fd0 < 0)
		return 1;
	write(fd0, "0", 1);//��MDO���ڵ͵�ƽ�����봫��ģʽ
	iRet = set_opt(fd, 9600, 8, 'N', 1);
	if (iRet)
	{
		printf("set port err!\n");
		return -1;
	}
	close(fd0);
	return 0;
}


void LoRa_msg_AT(int fd)
{
	char c[2048];//����ATָ��
	lora_AT_req(fd);//��ʼ��ʱ loraΪ����ģʽ
	sleep(3);
	strcpy(c, "AT+CWMODE=0\r\n");//���ô���ģʽ
	write(fd, c, strlen(c));
	sleep(3);
	lora_NAT_req(fd);//������ģʽ
	sleep(1);
}

void LoRa_sig_AT(int fd)
{
	char c[2048];//����ATָ��
	lora_AT_req(fd);//��ʼ��ʱ loraΪ����ģʽ
	sleep(3);
	strcpy(c, "AT+CWMODE=3\r\n");//�����ź�ģʽ
	write(fd, c, strlen(c));
	sleep(3);
	lora_NAT_req(fd);//������ģʽ
	sleep(1);
}

