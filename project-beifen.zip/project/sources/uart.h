#ifndef __UART_H
#define __UART_H



int set_opt(int fd, int nSpeed, int nBits, char nEvent, int nStop);
int open_port(char* com);

#endif