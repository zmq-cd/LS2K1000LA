#ifndef __DRI_RB_LED_H

#define __DRI_RB_LED_H//一般是文件名的大写
#define  RED_GPIO_INDEX     "58"
#define  YELLOW_GPIO_INDEX  "56"
#define  GREEN_GPIO_INDEX  "40"


int rbled_init(void);
int rbled_deinit(void);
int red_on(void);
int red_off(void);
int yellow_on(void);
int yellow_off(void);
int green_on(void);
int green_off(void);

// 打开颜色灯几秒钟
void choose_color_time(char* color, int time, int* led_cnt);
void traffic_led_mod(int red_time,int green_time);

#endif