#ifndef __DHT20_H
#define __DHT20_H
#include <stdint.h>

static int i2c_write_dht(int fd, unsigned char addr, const void* pBuf, size_t size);
static int i2c_read(int fd, uint8_t addr, void* pBuf, size_t size);
int DFRobot_DHT20_Init(int fd, unsigned char addr);
float getTemperature(int fd, unsigned char addr);
float getHumidity(int fd, unsigned char addr);

#endif
