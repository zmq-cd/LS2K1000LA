#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/select.h>
#include <sys/time.h>
#include <errno.h>
#include <linux/i2c.h>
#include <linux/i2c-dev.h>
#include <string.h>
#include <termios.h>
#include <pthread.h>
#include <semaphore.h>

#include "oled_app.h"
#include "uart.h"
#include "dht20.h"  
#include "mpu6050.h"
#include "ap3216c.h"
#include "dri_rb_led.h"
#include "lora.h"

#define Address         0x3c //OLED设备地址   
#define Address1        0x38 //DHT20设备地址
#define Address2        0x68 //MPU6050设备地址

ap3216c_data stru_data;
extern int fd; //i2c-1
extern int fd1;//ttyS3
extern const unsigned char BMP1[];
float temperature, humidity;
unsigned char temperatureS[20];
unsigned char humidityS[20];
unsigned char lightS[20];
unsigned char CarS[20];
unsigned char L_C[20];
unsigned char snrS[20];
unsigned char RSSIS[20];
unsigned char S_R[20];

float pitch, roll, yaw;
float dt = 0.01;  // 时间间隔，假设10ms采样一次
unsigned short als, ir;//光照和距离
int res;
int red_time, green_time;
int next_red_t = 5, next_green_t = 5;
int car;//车流量统计
int distance;//距离测量
extern int led_int;//红绿灯计时数据
int snr;
float rssi,dist;
pthread_mutex_t mutex;//互斥锁

//子线程1（红绿灯周期显示，周期结束时接收LoRa传来的数据）
void* thread_display_redblue(void* arg)
{   
    while (1)
    {
        red_time = next_red_t;
        green_time = next_green_t;
        //添加接收数据包的信息至红绿灯显示模块中，设置各显示时长。
        traffic_led_mod(red_time, green_time);
    }
}

//子线程2（车流量和光照检测）
void* Car_detect(void* arg)
{
    int car_cnt,car_start;
    while (1)
    {
        //printf("照射强度 = %d, 测距 = %d，车流量 = %d\r\n",
        //    stru_data.als, stru_data.ir, car);
        ap3216c_read_datas(&stru_data);
        usleep(1000 * 10);
        als = stru_data.als;//获取光照
        if (als > 256)
            als = 255;
        ir = stru_data.ir;  //获取距离
        //判断距离->车流量
        if (ir > 50)
            car_start = 1; //车辆与传感器距离小于阙值，标志位打开
        else
            car_start = 0; //车辆与传感器距离大于阙值，标志位打开

        if (car_start == 1)
            car_cnt = car_cnt+1;
        else
            car_cnt = 0;

        if (car_cnt == 5) 
            car = car +1;        //如果计数大于5，车流量加1. 
        sprintf(lightS, "light:%d", ir);
        sprintf(CarS, "car:%d", car);
        sprintf(L_C, "%s %s", lightS, CarS);
        usleep(1000*100);
    }
}

//子线程3 LoRa串口读取数据（LoRa模式0）
void* read_lora(void* arg)
{
    char buf_lora[1024];
    char temp_str[20]; // 用于存放第5到第9位的子字符串
    int n;
    
    while (1)
    {
        usleep(1000 * 100);
        // 读取LoRa网关的数据（A）
        n = read(fd1, buf_lora, sizeof(buf_lora));
        usleep(1000 * 100);
        if (n > 0) {
            //printf("Received data: %.*s\n", n, buf_lora);
            if (buf_lora[0] == 'A' && buf_lora[1] == 'L') {
                next_red_t = (int)(buf_lora[2]);
                next_green_t = (int)(buf_lora[3]);
                //printf("receive_success,red_time=%d,green_time=%d\n", red_time, green_time);
            }
            else if (buf_lora[0] == 'S' && buf_lora[1] == 'N' && buf_lora[2] == 'R') {
                if(buf_lora[6] == '\0')
                    snr = buf_lora[5]-'0';
                else {
                    snr = (buf_lora[5] - '0')*10+ (buf_lora[6] - '0');
                }
                sprintf(snrS, "snr:%d",snr);
                //printf("%s\n", buf_lora);
                //sleep(1);
                //printf("%d\n", buf_lora);
                //sleep(1);
            }                
            else if (buf_lora[0] == 'R' && buf_lora[1] == 'S' && buf_lora[2] == 'S' && buf_lora[3] == 'I') {
                strncpy(temp_str, buf_lora + 7, 9);
                temp_str[9] = '\0'; // 添加字符串终止符
                rssi = -1*atof(temp_str);
                sprintf(RSSIS, "rssi:%.2f", rssi);
                //printf("%s\n", buf_lora);
                //sleep(1);                
                //printf("%d\n", buf_lora);
            }
            else
            //printf("%.*s\n", n, buf_lora);
            sprintf(S_R, "%s %s", snrS, RSSIS);
        }
    }
}


/* 主函数  */
int main(int argc, char* argv[])
{
    int i = 0; //用于循环
    int flag_location = 0;//计数模式转换
    pthread_t tid;//线程1
    pthread_t tid1;//线程2
    pthread_t tid2;//线程3
    void* tret;
    int iRet;
    char trans_buffer[20]; //LoRa串口发送缓存器
    char buf[1024];

    if (argc < 3) {
        printf("Wrong use !!!!\n");
        printf("Usage: %s [dev]\n", argv[0]);
        return -1;
    }
    fd = open(argv[1], O_RDWR); // open file and enable read and  write
    if (fd < 0) {
        printf("Can't open %s \n", argv[1]); // open i2c dev file fail
        exit(1);
    }
    fd1 = open(argv[2], O_RDWR); // open file and enable read and  write
    if (fd1 < 0) {
        printf("Can't open %s \n", argv[2]); // open i2c dev file fail
        exit(1);
    }
    float lora_dist_detect(float rssi)
    {
        int A = -28;
        float n = 2.5;
        dist = pow(10, (A - rssi) / (10 * n);
        printf("dist:%.2f", dist);
        sleep(1);
        return dist;
    }

    void datapack(void)
    {
        trans_buffer[0] = 'L';
        trans_buffer[1] = 'B';
        trans_buffer[2] = (char)temperature;
        trans_buffer[3] = (char)(((int)(humidity * 100)));//百分数转化（%-1）
        trans_buffer[4] = (char)(((int)(als)));
        trans_buffer[5] = (char)(car);
        trans_buffer[6] = (char)(((int)(dist)));
        trans_buffer[7] = (char)(((int)(dist * 100))%100);

    }
    //初始化各个模块
    pthread_mutex_init(&mutex, NULL);//互斥锁初始化
    OLED_Init(fd, Address); //初始化oled
    usleep(1000 * 100);
    DFRobot_DHT20_Init(fd, Address1);//初始化DHT20
    usleep(1000 * 10);
    mpu6050_init(fd, Address2);//初始化MPU6050
    usleep(1000 * 10);
    ap3216c_init(); //初始化AP3216
    usleep(1000 * 10);
    iRet = rbled_init();//初始化红绿灯
    usleep(1000 * 10);
    if (iRet)
    {
        printf("rbled_init init error,code = %d", iRet);
        return 0;
    }
    iRet = set_opt(fd1, 9600, 8, 'N', 1); //初始化串口
    if (iRet)
    {
        printf("set port err!\n");
        return -1;
    }
    iRet = MD0_init();
    usleep(1000 * 10);
    if (iRet)
    {
        printf("rbled_init init error,code = %d", iRet);
        return 0;
    }
    usleep(1000 * 10);
    LoRa_msg_AT(fd1);

    if (pthread_create(&tid, NULL, thread_display_redblue, NULL) != 0) {
        perror("pthread_create error \n");
        return -1;
    }

    if (pthread_create(&tid1, NULL, Car_detect, NULL) != 0) {
        perror("pthread_create error \n");
        return -1;
    }

    if (pthread_create(&tid2, NULL, read_lora, NULL) != 0) {
        perror("pthread_create error \n");
        return -1;
    }

    while (1)
    {
        flag_location++;
        //每5次转换模式，信号强度检测
        if (flag_location == 5) {
            //printf("mod3 start");
            LoRa_sig_AT(fd1);            
            flag_location = 0;
            sleep(1);
        }
        //LoRa汇总各线程的数据，处理部分后发送至网关（LoRa模式0）
        temperature = getTemperature(fd, Address1);  // 获取温度
        usleep(1000 * 10);
        humidity = getHumidity(fd, Address1);       //  获取湿度
        usleep(1000 * 10);
        sprintf(temperatureS, "temerature:%.2f", temperature);
        sprintf(humidityS, "humidity:%.2f", humidity);
        dist = lora_dist_detect(rssi);
        datapack();
        sleep(5);
        if (flag_location == 0) {
            write(fd1, "LA", 2);//LoRa发送 
        }   
        else {
            write(fd1, trans_buffer, 11);//LoRa发送  
            //printf("send LB");
        }   
        sleep(5);
        if (flag_location == 0) {
            LoRa_msg_AT(fd1);
            sleep(2);
        }
    }
    close(fd);
    close(fd1);
    ap3216c_release();
    pthread_join(tid, &tret);
    pthread_join(tid1, &tret);
    pthread_join(tid2, &tret);
}
